'use client'
import { useEffect, useMemo, useRef, useState, useCallback } from 'react'
import { createClient } from '@/lib/supabase/client'
import { fmtDate, fmtDateTime } from '@/lib/format'

interface Venue { id: string; name: string }
interface Row {
  id: string; status: string; qr_token: string
  first_name: string; last_name: string; mobile: string; email: string | null
  promoter_name: string; promoter_code: string
  checked_in_at: string | null; notes: string | null; special_occasion: string | null
  method: string | null; plus_ones: number
}
type ScanResult = { kind: 'ok' | 'err' | 'warn'; title: string; sub?: string } | null

function localToday() {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

export function ReceptionConsole({ venues }: { venues: Venue[] }) {
  const supabase = useMemo(() => createClient(), [])
  const [venueId, setVenueId] = useState(venues[0]?.id ?? '')
  const [date, setDate] = useState('')
  const [rows, setRows] = useState<Row[]>([])
  const [q, setQ] = useState('')
  const [toast, setToast] = useState<{ kind: 'ok' | 'warn' | 'err'; msg: string } | null>(null)
  const [scanning, setScanning] = useState(false)
  const [scanResult, setScanResult] = useState<ScanResult>(null)
  const [loading, setLoading] = useState(false)

  const flash = (kind: 'ok' | 'warn' | 'err', msg: string) => {
    setToast({ kind, msg }); setTimeout(() => setToast(null), 3500)
  }

  useEffect(() => {
    if (!scanResult) return
    const t = setTimeout(() => setScanResult(null), 2400)
    return () => clearTimeout(t)
  }, [scanResult])

  // set "today" on the client to avoid SSR/client timezone hydration mismatch
  useEffect(() => { setDate(localToday()) }, [])

  const load = useCallback(async () => {
    if (!venueId || !date) { setRows([]); return }
    setLoading(true)
    const { data } = await supabase
      .from('guest_registrations')
      .select('id,status,qr_token,special_occasion,plus_ones,guests(first_name,last_name,mobile,email),promoters(full_name,promoter_code),check_ins(checked_in_at,notes,method),events!inner(event_date)')
      .eq('venue_id', venueId).eq('events.event_date', date)
      .order('created_at', { ascending: false })
    const mapped: Row[] = (data ?? []).map((r: any) => ({
      id: r.id, status: r.status, qr_token: r.qr_token,
      first_name: r.guests?.first_name ?? '', last_name: r.guests?.last_name ?? '',
      mobile: r.guests?.mobile ?? '', email: r.guests?.email ?? null,
      promoter_name: r.promoters?.full_name ?? '', promoter_code: r.promoters?.promoter_code ?? '',
      checked_in_at: r.check_ins?.[0]?.checked_in_at ?? r.check_ins?.checked_in_at ?? null,
      special_occasion: r.special_occasion ?? null,
      notes: r.check_ins?.[0]?.notes ?? null,
      method: r.check_ins?.[0]?.method ?? r.check_ins?.method ?? null,
      plus_ones: r.plus_ones ?? 0,
    }))
    setRows(mapped); setLoading(false)
  }, [venueId, date, supabase])

  useEffect(() => { load() }, [load])

  useEffect(() => {
    if (!venueId || !date) return
    const ch = supabase.channel(`door-${venueId}-${date}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'check_ins' }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'guest_registrations', filter: `venue_id=eq.${venueId}` }, load)
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [venueId, date, supabase, load])

  const stats = useMemo(() => {
    const heads = (r: Row) => 1 + (r.plus_ones || 0)
    const registered = rows.reduce((s, r) => s + heads(r), 0)
    const checked = rows.filter(r => r.status === 'checked_in').reduce((s, r) => s + heads(r), 0)
    const noEntry = rows.filter(r => r.status === 'no_entry').reduce((s, r) => s + heads(r), 0)
    return { registered, checked, remaining: registered - checked - noEntry, noEntry }
  }, [rows])

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase()
    if (!t) return rows
    return rows.filter(r =>
      `${r.first_name} ${r.last_name}`.toLowerCase().includes(t) ||
      r.mobile.toLowerCase().includes(t) ||
      (r.email ?? '').toLowerCase().includes(t) ||
      r.promoter_name.toLowerCase().includes(t) ||
      r.promoter_code.toLowerCase().includes(t))
  }, [rows, q])

  const latest = useMemo(() =>
    rows.filter(r => r.checked_in_at).sort((a, b) =>
      (b.checked_in_at || '').localeCompare(a.checked_in_at || '')).slice(0, 6), [rows])

  async function checkIn(r: Row, noEntry = false) {
    if (r.status === 'checked_in' && !noEntry) {
      flash('warn', `${r.first_name} ${r.last_name} is already checked in`); return
    }
    const { data, error } = await supabase.rpc('check_in_guest', {
      p_registration: r.id, p_no_entry: noEntry, p_notes: null,
    })
    if (error) { flash('err', error.message); return }
    if (!data?.ok) {
      if (data?.error === 'already_checked_in') flash('warn', `${r.first_name} already checked in`)
      else flash('err', 'Could not check in — ' + (data?.error ?? 'error'))
      return
    }
    flash(noEntry ? 'warn' : 'ok', noEntry ? `No entry: ${r.first_name} ${r.last_name}` : `Checked in: ${r.first_name} ${r.last_name} ✓`)
    load()
  }

  async function checkInByToken(token: string) {
    const { data, error } = await supabase.rpc('check_in_by_token', {
      p_token: token, p_no_entry: false, p_notes: null, p_expected_date: date,
    })
    if (error) { setScanResult({ kind: 'err', title: 'ERROR', sub: error.message }); return }
    if (!data?.ok) {
      if (data?.error === 'already_checked_in')
        setScanResult({ kind: 'err', title: 'ALREADY CHECKED IN', sub: data.guest_name || '' })
      else if (data?.error === 'wrong_date')
        setScanResult({ kind: 'warn', title: 'WRONG DATE', sub: data.event_date ? `This QR is for ${fmtDate(data.event_date)}` : 'Not for tonight' })
      else if (data?.error === 'not_found')
        setScanResult({ kind: 'err', title: 'NOT RECOGNISED', sub: 'QR not in this system' })
      else if (data?.error === 'not_authorised')
        setScanResult({ kind: 'err', title: 'WRONG VENUE', sub: 'Guest is for another venue' })
      else setScanResult({ kind: 'err', title: 'CHECK-IN FAILED' })
      load(); return
    }
    setScanResult({ kind: 'ok', title: 'CHECKED IN', sub: data.guest_name || '' })
    load()
  }

  return (
    <div className="space-y-5">
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="label">Venue</label>
          <select className="input" value={venueId} onChange={e => setVenueId(e.target.value)}>
            {venues.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Date</label>
          <input className="input" type="date" value={date} onChange={e => setDate(e.target.value)} />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="stat"><div className="stat-num">{stats.registered}</div><div className="stat-lbl">Registered</div></div>
        <div className="stat"><div className="stat-num text-emerald-400">{stats.checked}</div><div className="stat-lbl">Checked in</div></div>
        <div className="stat"><div className="stat-num text-luna-gold">{stats.remaining}</div><div className="stat-lbl">Remaining</div></div>
      </div>

      <div className="flex gap-3">
        <input className="input flex-1 text-lg" placeholder="Search name, phone, email or promoter…"
          value={q} onChange={e => setQ(e.target.value)} autoFocus />
        <button className="btn-gold px-6 text-lg" onClick={() => setScanning(true)}>Scan QR</button>
      </div>

      {toast && (
        <div className={`fixed left-1/2 -translate-x-1/2 top-4 z-50 px-5 py-3 rounded-xl font-semibold shadow-glow ${
          toast.kind === 'ok' ? 'bg-emerald-500 text-black' :
          toast.kind === 'warn' ? 'bg-amber-400 text-black' : 'bg-red-500 text-white'}`}>
          {toast.msg}
        </div>
      )}

      {latest.length > 0 && (
        <div className="card p-4">
          <p className="text-xs uppercase tracking-wide text-luna-muted mb-2">Latest check-ins</p>
          <div className="flex flex-wrap gap-2">
            {latest.map(r => (
              <span key={r.id} className="pill bg-emerald-500/10 text-emerald-400">
                {r.first_name} {r.last_name} · {fmtDateTime(r.checked_in_at)}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-2">
        {loading && <p className="text-luna-muted text-sm">Loading…</p>}
        {!loading && filtered.length === 0 && <p className="text-luna-muted text-sm py-6 text-center">No guests on the list for this venue &amp; date.</p>}
        {filtered.map(r => (
          <div key={r.id} className={`card p-4 flex items-center gap-3 ${r.status === 'checked_in' ? 'border-emerald-500/40' : r.status === 'no_entry' ? 'border-red-500/40' : ''}`}>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-lg truncate flex items-center gap-2">
                {r.first_name} {r.last_name}
                {r.plus_ones > 0 && <span className="pill bg-luna-gold/20 text-luna-gold text-[11px]">+{r.plus_ones}</span>}
                {r.special_occasion && <span className="pill bg-luna-purple/25 text-white text-[11px]">🎉 {r.special_occasion}</span>}
              </div>
              <div className="text-sm text-luna-muted truncate">
                {r.mobile} · {r.promoter_name} ({r.promoter_code})
                {r.checked_in_at && <span className="text-emerald-400"> · in {fmtDateTime(r.checked_in_at)}{r.method ? ` (${r.method === 'scan' ? 'scanned' : 'manual'})` : ''}</span>}
              </div>
            </div>
            {r.status === 'checked_in' ? (
              <span className="pill bg-emerald-500/15 text-emerald-400">Checked in ✓</span>
            ) : r.status === 'no_entry' ? (
              <span className="pill bg-red-500/15 text-red-400">No entry</span>
            ) : (
              <div className="flex gap-2">
                <button className="btn-danger !px-3 !py-2 text-sm" onClick={() => checkIn(r, true)}>No entry</button>
                <button className="btn-gold !px-4 !py-2" onClick={() => checkIn(r)}>Check in</button>
              </div>
            )}
          </div>
        ))}
      </div>

      {scanning && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col">
          <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
            <div className="min-w-0">
              <div className="text-white font-semibold text-lg">Scan guest QR</div>
              <div className="text-luna-muted text-sm truncate">
                {venues.find(v => v.id === venueId)?.name} · {fmtDate(date)}
              </div>
            </div>
            <button onClick={() => { setScanning(false); setScanResult(null) }}
              className="btn-ghost !py-3 !px-6 text-lg">Close</button>
          </div>

          <div className="flex-1 flex items-center justify-center p-4">
            <QRScanner onScan={checkInByToken} onError={(m) => setScanResult({ kind: 'err', title: 'CAMERA ERROR', sub: m })} />
          </div>
          <p className="text-center text-luna-muted pb-6 text-lg">Point the camera at the guest&apos;s QR code</p>

          {scanResult && (
            <div className={`fixed inset-0 z-[60] flex flex-col items-center justify-center text-center px-8 ${
              scanResult.kind === 'ok' ? 'bg-emerald-500' : scanResult.kind === 'warn' ? 'bg-amber-500' : 'bg-red-600'}`}>
              <div className="text-white" style={{ fontSize: '7rem', lineHeight: 1 }}>
                {scanResult.kind === 'ok' ? '✓' : scanResult.kind === 'warn' ? '⚠' : '✕'}
              </div>
              <div className="text-white font-extrabold mt-4" style={{ fontSize: '3rem', lineHeight: 1.05 }}>
                {scanResult.title}
              </div>
              {scanResult.sub && <div className="text-white/90 mt-4 text-2xl font-semibold">{scanResult.sub}</div>}
              <div className="text-white/70 mt-8 text-base">Ready for the next guest…</div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function QRScanner({ onScan, onError }: { onScan: (token: string) => void; onError: (m: string) => void }) {
  const ref = useRef<HTMLDivElement>(null)
  const lastRef = useRef<string>('')
  useEffect(() => {
    let scanner: any
    let cancelled = false
    ;(async () => {
      try {
        if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          onError('Camera not available in this browser. Open the site in Safari or Chrome, or use search + manual check-in.')
          return
        }
        const { Html5Qrcode } = await import('html5-qrcode')
        if (cancelled || !ref.current) return
        scanner = new Html5Qrcode(ref.current.id)
        await scanner.start({ facingMode: 'environment' }, { fps: 10, qrbox: 300 },
          (text: string) => {
            const token = (text.split('/g/')[1] || text).split(/[?#]/)[0]
            if (token && token !== lastRef.current) {
              lastRef.current = token
              onScan(token)
              setTimeout(() => { lastRef.current = '' }, 3000)
            }
          }, () => {})
      } catch (e: any) { onError('Camera unavailable — use search + manual check-in.') }
    })()
    return () => { cancelled = true; if (scanner) scanner.stop().catch(() => {}) }
  }, [onScan, onError])
  return (
    <div className="w-full max-w-md">
      <div id="qr-reader" ref={ref} className="w-full rounded-2xl overflow-hidden bg-black" />
    </div>
  )
}
