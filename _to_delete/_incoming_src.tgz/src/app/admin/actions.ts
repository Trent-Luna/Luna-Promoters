'use server'
import { createClient, createServiceClient } from '@/lib/supabase/server'
import { getSession, hasRole } from '@/lib/auth'
import { revalidatePath } from 'next/cache'

async function ensureAdmin() {
  const s = await getSession()
  if (!hasRole(s, 'admin')) throw new Error('Not authorised')
  return s!
}
async function ensureManager() {
  const s = await getSession()
  if (!hasRole(s, 'admin', 'venue_manager')) throw new Error('Not authorised')
  return s!
}

export async function approvePromoter(id: string) {
  await ensureAdmin()
  const supabase = await createClient()
  const { error } = await supabase.rpc('approve_promoter', { p_id: id })
  if (error) throw error
  revalidatePath('/admin/promoters')
}

export async function setPromoterStatus(id: string, status: 'rejected' | 'suspended' | 'approved') {
  const s = await ensureAdmin()
  const supabase = await createClient()
  const { error } = await supabase.from('promoters').update({ status }).eq('id', id)
  if (error) throw error
  await supabase.rpc('log_action', {
    p_action: `promoter_${status}`, p_user: s.userId, p_promoter: id,
  })
  revalidatePath('/admin/promoters')
}

export async function addPromoterNote(promoterId: string, note: string) {
  const s = await ensureAdmin()
  const supabase = await createClient()
  const { error } = await supabase.from('admin_notes').insert({ promoter_id: promoterId, author_id: s.userId, note })
  if (error) throw error
  revalidatePath('/admin/promoters')
}

export async function setEliteOverride(id: string, elite: boolean) {
  await ensureAdmin()
  const supabase = await createClient()
  const { error } = await supabase.from('promoters')
    .update({ elite_override: elite, current_tier: elite ? 'elite' : 'bronze' }).eq('id', id)
  if (error) throw error
  revalidatePath('/admin/promoters')
}

export async function createVenue(fd: FormData) {
  await ensureAdmin()
  const supabase = await createClient()
  const name = String(fd.get('name') || '').trim()
  const slug = String(fd.get('slug') || '').trim() || name.toLowerCase().replace(/[^a-z0-9]+/g, '-')
  const { error } = await supabase.from('venues').insert({ name, slug, address: String(fd.get('address') || '') || null })
  if (error) throw error
  revalidatePath('/admin/venues')
}

export async function toggleVenue(id: string, active: boolean) {
  await ensureAdmin()
  const supabase = await createClient()
  await supabase.from('venues').update({ active }).eq('id', id)
  revalidatePath('/admin/venues')
}

/**
 * Permanently remove a venue — but only when nothing points at it.
 *
 * `venues` is the parent of six cascading foreign keys (events,
 * guest_registrations, roles, blackout_dates, whats_on, and venue rooms), so an
 * unguarded delete would take every historical guest and check-in for that venue
 * with it, silently. This exists for the realistic case — a venue added by
 * mistake or a typo — and refuses everything else, pointing at Disable instead,
 * which already removes a venue from the public guestlist and every picker.
 */
export async function deleteVenue(id: string): Promise<{ ok: boolean; error?: string }> {
  await ensureAdmin()
  const supabase = await createClient()

  // Count anything that would be destroyed by the cascade. head+exact gives a
  // count without pulling rows back.
  const [events, regs, roles, blackouts] = await Promise.all([
    supabase.from('events').select('id', { count: 'exact', head: true }).eq('venue_id', id),
    supabase.from('guest_registrations').select('id', { count: 'exact', head: true }).eq('venue_id', id),
    supabase.from('roles').select('id', { count: 'exact', head: true }).eq('venue_id', id),
    supabase.from('blackout_dates').select('id', { count: 'exact', head: true }).eq('venue_id', id),
  ])

  const blockers: string[] = []
  if (events.count) blockers.push(`${events.count} event${events.count === 1 ? '' : 's'}`)
  if (regs.count) blockers.push(`${regs.count} guest registration${regs.count === 1 ? '' : 's'}`)
  if (roles.count) blockers.push(`${roles.count} staff role${roles.count === 1 ? '' : 's'}`)
  if (blackouts.count) blockers.push(`${blackouts.count} blackout date${blackouts.count === 1 ? '' : 's'}`)

  if (blockers.length > 0) {
    return {
      ok: false,
      error: `This venue has ${blockers.join(', ')}. Deleting it would remove that history too. Disable it instead — it disappears from the guestlist and every picker, and the records stay.`,
    }
  }

  const { error } = await supabase.from('venues').delete().eq('id', id)
  if (error) return { ok: false, error: error.message }

  revalidatePath('/admin/venues')
  return { ok: true }
}

export async function createEvent(fd: FormData) {
  const s = await ensureManager()
  const supabase = await createClient()
  const payload: any = {
    venue_id: fd.get('venue_id'), name: String(fd.get('name')),
    event_date: fd.get('event_date'),
    start_time: fd.get('start_time') || null, end_time: fd.get('end_time') || null,
    description: String(fd.get('description') || '') || null,
    guestlist_open: fd.get('guestlist_open') === 'on',
    created_by: s.userId,
  }
  const { data, error } = await supabase.from('events').insert(payload).select('id,venue_id').single()
  if (error) throw error
  await supabase.rpc('log_action', { p_action: 'event_created', p_user: s.userId, p_venue: data.venue_id, p_event: data.id })
  revalidatePath('/admin/events')
}

export async function toggleGuestlist(id: string, open: boolean) {
  await ensureManager()
  const supabase = await createClient()
  await supabase.from('events').update({ guestlist_open: open }).eq('id', id)
  revalidatePath('/admin/events')
}

export async function updateTier(fd: FormData) {
  await ensureAdmin()
  const supabase = await createClient()
  const name = String(fd.get('name'))
  const min = fd.get('min_guests') ? Number(fd.get('min_guests')) : null
  const max = fd.get('max_guests') ? Number(fd.get('max_guests')) : null
  const { error } = await supabase.from('tiers')
    .update({ min_guests: min, max_guests: max, perks: String(fd.get('perks') || '') }).eq('name', name)
  if (error) throw error
  revalidatePath('/admin/tiers')
}

// ---------- Staff management (admin creates managers / door staff) ----------
export async function createStaff(fd: FormData) {
  await ensureAdmin()
  const email = String(fd.get('email') || '').trim().toLowerCase()
  const fullName = String(fd.get('full_name') || '').trim()
  const password = String(fd.get('password') || '')
  const role = String(fd.get('role') || '') as 'admin' | 'venue_manager' | 'reception'
  const venueId = String(fd.get('venue_id') || '') || null

  if (!email || password.length < 6) throw new Error('Email and a 6+ character password are required')
  if ((role === 'venue_manager' || role === 'reception') && !venueId)
    throw new Error('Please choose a venue for this role')

  const svc = createServiceClient()

  // create the auth user (or reuse if they already exist)
  let userId: string | null = null
  const { data: created, error: createErr } = await svc.auth.admin.createUser({
    email, password, email_confirm: true, user_metadata: { full_name: fullName },
  })
  if (created?.user) {
    userId = created.user.id
  } else {
    // user may already exist — find their id from the profile table
    const { data: existing } = await svc.from('users').select('id').eq('email', email).maybeSingle()
    if (existing?.id) userId = existing.id
    else throw new Error(createErr?.message || 'Could not create the account')
  }

  // make sure the profile carries their name (for leaderboards etc.)
  if (fullName && userId) await svc.from('users').update({ full_name: fullName }).eq('id', userId)

  // grant the role (venue-scoped for manager/reception)
  const { error: roleErr } = await svc.from('roles')
    .insert({ user_id: userId, role, venue_id: venueId })
  if (roleErr && !roleErr.message.includes('duplicate')) throw roleErr

  await svc.rpc('log_action', { p_action: `staff_added_${role}`, p_user: (await ensureAdmin()).userId })
  revalidatePath('/admin/staff')
}

export async function removeStaffRole(roleId: string) {
  await ensureAdmin()
  const supabase = await createClient()
  const { error } = await supabase.from('roles').delete().eq('id', roleId)
  if (error) throw error
  revalidatePath('/admin/staff')
}

// ---------- Auto-approve setting ----------
export async function setAutoApprove(on: boolean) {
  await ensureAdmin()
  const supabase = await createClient()
  const { error } = await supabase.from('app_settings')
    .update({ auto_approve_promoters: on, updated_at: new Date().toISOString() }).eq('id', 1)
  if (error) throw error
  revalidatePath('/admin/promoters')
}

// ---------- Blackout dates ----------
export async function addBlackout(fd: FormData) {
  const s = await ensureManager()
  const supabase = await createClient()
  const venueRaw = String(fd.get('venue_id') || '')
  const venue_id = venueRaw === 'ALL' ? null : venueRaw || null
  const date = String(fd.get('blackout_date') || '')
  const reason = String(fd.get('reason') || '') || null
  if (!date) throw new Error('Please choose a date')
  // venue managers cannot create all-venue blackouts
  if (!s.roles.includes('admin') && !venue_id) throw new Error('Only admins can black out all venues')
  const { error } = await supabase.from('blackout_dates')
    .insert({ venue_id, blackout_date: date, reason, created_by: s.userId })
  if (error) throw error.message.includes('duplicate') ? new Error('That date is already blacked out for this venue') : error
  revalidatePath('/admin/blackout')
}

export async function removeBlackout(id: string) {
  await ensureManager()
  const supabase = await createClient()
  const { error } = await supabase.from('blackout_dates').delete().eq('id', id)
  if (error) throw error
  revalidatePath('/admin/blackout')
}

// ---------- Promoter category (promoter / dj / staff) ----------
export async function setPromoterCategory(id: string, category: 'promoter' | 'dj' | 'staff') {
  await ensureAdmin()
  const supabase = await createClient()
  const { error } = await supabase.from('promoters').update({ category }).eq('id', id)
  if (error) throw error
  revalidatePath('/admin/promoters')
}

// ---------- What's On (venue newsfeed) ----------
export async function createPost(fd: FormData) {
  const s = await ensureManager()
  const supabase = await createClient()
  const venueRaw = String(fd.get('venue_id') || '')
  const venue_id = venueRaw === 'ALL' ? null : (venueRaw || null)
  const title = String(fd.get('title') || '').trim()
  const body = String(fd.get('body') || '').trim() || null
  const image_url = String(fd.get('image_url') || '').trim() || null
  if (!title) throw new Error('A title is required')
  if (!s.roles.includes('admin') && !venue_id) throw new Error('Only admins can post to all venues')
  const { error } = await supabase.from('venue_posts')
    .insert({ venue_id, title, body, image_url, created_by: s.userId })
  if (error) throw error
  revalidatePath('/admin/whats-on')
}

export async function deletePost(id: string) {
  await ensureManager()
  const supabase = await createClient()
  const { error } = await supabase.from('venue_posts').delete().eq('id', id)
  if (error) throw error
  revalidatePath('/admin/whats-on')
}
